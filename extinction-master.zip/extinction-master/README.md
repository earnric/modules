extinction
==========

*Fast interstellar dust extinction laws in Python*

[![Build Status](http://img.shields.io/travis/kbarbary/extinction.svg?style=flat-square&label=linux)](https://travis-ci.org/kbarbary/extinction)
[![Build status](https://img.shields.io/appveyor/ci/kbarbary/extinction.svg?style=flat-square&label=windows)](https://ci.appveyor.com/project/kbarbary/extinction/branch/master)
[![PyPI](https://img.shields.io/pypi/v/extinction.svg?style=flat-square)](https://pypi.python.org/pypi/extinction)

documentation: http://extinction.readthedocs.io/
